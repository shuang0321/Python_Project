(1)
Name: Shuhui Huang
SID:3032129712

(2)
How to use my code to reproduce my results:

Just copy the code from the appendix of my write-up and run it on either Ipython, Jupyter or spyder.

Or you can also run the S.Huang_hw1.py directly and get the same result as me.